# fluxlseg

MBS wrapper around LSEG Python SDK for power, gas, and CO₂ market data.

## Install the version from package directory:
```bash
uv pip install -e . --force-reinstall
```


## Install the package elsewhere:
```bash
python -m build
```

```bash
uv pip install path/to/flux_lseg-0.1.0.tar.gz
```
