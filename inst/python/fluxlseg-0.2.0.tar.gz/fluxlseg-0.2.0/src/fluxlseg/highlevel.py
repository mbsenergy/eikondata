from fluxlseg.lowlevel import get_rics_d, get_rics_h, get_rics_f
import importlib.resources as pkg_resources
from fluxlseg import data
import pandas as pd
import lseg.data as ld
import warnings
from datetime import date, datetime, timedelta
import time
import json


def retrieve_spot(ric, start_date, end_date, type="PWR", sleep=0):
    """
    Retrieve spot market data (power hourly or gas daily) for one or more RICs.

    Parameters
    ----------
    ric : str or list of str
        One or more RICs to retrieve.
    start_date : str or datetime.date
        Start date (inclusive).
    end_date : str or datetime.date
        End date (inclusive).
    type : str
        Market type: 'PWR' for hourly power data, 'GAS' for daily gas data.
    sleep : float
        Seconds to sleep between calls (default 0).

    Returns
    -------
    pd.DataFrame
        Spot market data with standardized columns.
        For GAS: DATE, RIC, VALUE
        For PWR: DATE, HOUR, RIC, VALUE
    """

    if isinstance(ric, str):
        ric = [ric]

    if type.upper() == "GAS":
        frames = []
        for r in ric:
            df = get_rics_d(r, from_date=start_date, to_date=end_date, sleep=sleep)
            if df is not None and not df.empty:
                df["DATE"] = pd.to_datetime(df["DATE"]).dt.date
                df["RIC"] = r
                frames.append(df[["DATE", "RIC", "VALUE"]])
        if not frames:
            return pd.DataFrame(columns=["DATE", "RIC", "VALUE"])

        df_all = pd.concat(frames, ignore_index=True)
        df_all["VALUE"] = pd.to_numeric(df_all["VALUE"], errors="coerce")
        df_all.sort_values(by=["RIC", "DATE"], ascending=False, inplace=True)
        df_all["VALUE"] = df_all.groupby("RIC")["VALUE"].transform(
            lambda x: x.ffill().bfill()
        )

        print("[INFO] Spot Gas retrieval finished.")
        return df_all.reset_index(drop=True)

    elif type.upper() == "PWR":
        frames = []
        for r in ric:
            df = get_rics_h(r, start_date=start_date, end_date=end_date, sleep=sleep)
            if df is not None and not df.empty:
                df["DATE"] = pd.to_datetime(df["DATE"]).dt.date
                df["RIC"] = r
                df["HOUR"] = pd.to_numeric(df["HOUR"], errors="coerce")
                df["VALUE"] = pd.to_numeric(df["VALUE"], errors="coerce")
                frames.append(df[["DATE", "HOUR", "RIC", "VALUE"]])
        if not frames:
            return pd.DataFrame(columns=["DATE", "HOUR", "RIC", "VALUE"])

        df_all = pd.concat(frames, ignore_index=True)
        df_all = df_all[
            (df_all["DATE"] >= pd.to_datetime(start_date).date())
            & (df_all["DATE"] <= pd.to_datetime(end_date).date())
        ]
        df_all.sort_values(by=["DATE", "HOUR"], ascending=False, inplace=True)
        df_all["VALUE"] = df_all.groupby("RIC")["VALUE"].transform(
            lambda x: x.ffill().bfill()
        )

        print("[INFO] Spot Power retrieval finished.")
        return df_all.reset_index(drop=True)

    else:
        raise ValueError(f"Unknown type: {type}. Must be 'PWR' or 'GAS'.")


def retrieve_fwd(rics, start_date, end_date, sleep=0):
    """
    Retrieve and process forward RICs data.

    Parameters
    ----------
    rics : list of str
        List of RIC codes to retrieve.
    start_date : str or datetime.date
        Start date for historical data.
    end_date : str or datetime.date
        End date for historical data.
    sleep : int or float
        Seconds to sleep between API calls (default: 0).

    Returns
    -------
    pd.DataFrame
        Filtered DataFrame with columns: DATE, VALUE, RIC.
    """

    dfs = []
    for ric in rics:
        df = get_rics_f(ric=ric, from_date=start_date, to_date=end_date, sleep=sleep)
        if df is not None and not df.empty:
            dfs.append(df[["DATE", "VALUE", "RIC"]])
        if sleep > 0:
            time.sleep(sleep)

    if not dfs:
        warnings.warn("No data was retrieved.")
        return pd.DataFrame(columns=["DATE", "VALUE", "RIC"])

    df_all = pd.concat(dfs).reset_index(drop=True)
    df_all = df_all.dropna(subset=["RIC", "VALUE"])

    latest_rows = df_all.sort_values("DATE").groupby("RIC", as_index=False).last()

    print("\033[32m[INFO]\033[0m FWD retrieval finished.")

    return latest_rows[["DATE", "VALUE", "RIC"]]


def retrieve_cont(list_cont_codes, start_date, end_date, cont="c1", sleep=0):
    """
    Retrieve continuation data for a list of RICs by continuation code.

    Parameters
    ----------
    list_cont_codes : pd.DataFrame
        DataFrame with columns ['COMMODITY', 'c1', 'c2'], filtered in R and passed here.
    start_date : str or datetime.date
        Start of the historical period.
    end_date : str or datetime.date
        End of the historical period.
    cont : str
        Either 'c1' or 'c2' continuation column.
    sleep : float
        Optional pause between API calls (default: 0 seconds).

    Returns
    -------
    pd.DataFrame
        DataFrame with columns: DATE, RIC, VALUE, VOLUME.
    """

    if cont not in ["c1", "c2"]:
        raise ValueError("`cont` must be either 'c1' or 'c2'.")

    if list_cont_codes.empty:
        raise ValueError("Provided list_cont_codes is empty.")

    cont_codes = list_cont_codes[cont].dropna().unique().tolist()

    if not cont_codes:
        raise ValueError(
            "No matching RICs found for the given commodities and continuation."
        )

    frames = []
    for ric in cont_codes:
        try:
            result = ld.get_history(
                universe=ric,
                fields=["CF_NAME", "TRDPRC_1", "TR.ACCUMULATEDVOLUME"],
                interval="1D",
                start=start_date,
                end=end_date,
            )
        except Exception as e:
            print(f"Warning: Failed to retrieve {ric}: {e}")
            continue

        if result is None or result.empty:
            continue

        result = result.reset_index()
        result.columns = ["date", "value", "volume"]
        result["ric"] = ric
        result["value"] = pd.to_numeric(result["value"], errors="coerce")
        result["volume"] = pd.to_numeric(result["volume"], errors="coerce")
        frames.append(result[["date", "ric", "value", "volume"]])

        if sleep > 0:
            time.sleep(sleep)

    if not frames:
        return None

    df = pd.concat(frames).sort_values(["date", "ric"]).reset_index(drop=True)
    df.columns = ["DATE", "RIC", "VALUE", "VOLUME"]

    json_str = df.to_json(orient="records", date_format="iso")
    return json_str
