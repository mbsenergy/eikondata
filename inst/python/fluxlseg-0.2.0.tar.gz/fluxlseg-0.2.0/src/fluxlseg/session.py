import os
import lseg.data as ld

def open_session(LSEG_KEY=os.getenv("LSEG_APP_KEY_API")):
    """
    Open a session with the LSEG (Refinitiv) data platform using the provided API key.

    Parameters
    ----------
    LSEG_KEY : str, optional
        The LSEG App Key for authentication. By default, it is read from the 
        environment variable 'LSEG_APP_KEY_API'.

    Returns
    -------
    lseg.data
        The authenticated lseg.data module for making data requests.

    Raises
    ------
    ValueError
        If the LSEG_KEY is not provided or cannot be found in the environment.

    Notes
    -----
    This function initializes a session with the LSEG data platform. It must be 
    called before making any data retrieval requests using `lseg.data` (e.g., `get_history()`).
    """
    if not LSEG_KEY:
        raise ValueError("LSEG_APP_KEY_API environment variable not set")

    ld.open_session(app_key=LSEG_KEY)
    return ld
