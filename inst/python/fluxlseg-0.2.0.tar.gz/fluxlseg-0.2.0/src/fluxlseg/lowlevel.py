import pandas as pd
import lseg.data as ld
from lseg.data.content import historical_pricing
import warnings
from datetime import date, datetime, timedelta
import time


def get_rics_d(rics, from_date=None, to_date=None, sleep=0, headers_legacy=True):
    """
    Retrieve Daily time series data for a given base RIC.

    Parameters
    ----------
    ric : str
        Base RIC (e.g., 'GMEIT') without hour suffix.
    from_date : str or datetime.date, optional
        Start date (default: 10 years ago).
    to_date : str or datetime.date, optional
        End date (default: today).
    sleep : int or float
        Seconds to sleep between API calls (default: 0).
    headers_legacy : bool
        Whether to return legacy column names (date, ric, value, volume) or (DATE, RIC, VALUE, VOLUME).

    Returns
    -------
    pd.DataFrame
        DataFrame with columns: DATE, RIC, VALUE, VOLUME.
    """

    if from_date is None:
        from_date = date.today() - timedelta(days=365 * 10)
    if to_date is None:
        to_date = date.today()

    data_fields = ["CF_NAME", "TRDPRC_1", "TR.ACCUMULATEDVOLUME"]
    result = None  # Ensure result is defined

    try:
        result = ld.get_history(
            universe=rics,
            fields=data_fields,
            interval="1D",
            start=from_date,
            end=to_date,
        )
        time.sleep(sleep)
    except Exception as e:
        print(f"\033[31m[ERROR]\033[0m Failed to retrieve {rics}: {e}")
        return pd.DataFrame(columns=["DATE", "RIC", "VALUE", "VOLUME"])

    if result is None or result.empty:
        print(f"\033[33m[WARNING]\033[0m No data returned for RIC: {rics}")
        return pd.DataFrame(columns=["DATE", "RIC", "VALUE", "VOLUME"])

    if result["TRDPRC_1"].isna().all():
        result = pd.DataFrame(columns=["date", "ric", "value", "volume"])
    else:
        result = result[result["TRDPRC_1"].notna()]

    # Process result
    result = result.reset_index()
    result.columns = ["date", "value", "volume"]
    result["ric"] = rics
    result["value"] = pd.to_numeric(result["value"], errors="coerce")
    result["volume"] = pd.to_numeric(result["volume"], errors="coerce")
    result = (
        result[["date", "ric", "value", "volume"]]
        .sort_values("date")
        .reset_index(drop=True)
    )

    if headers_legacy is False:
        result.columns = ["date", "ric", "value", "volume"]

    # ANSI color codes
    GREEN = "\033[32m"
    ORANGE = "\033[33m"
    BLUE = "\033[34m"
    RESET = "\033[0m"

    print(
        f"{GREEN}[INFO]{RESET} "
        f"{BLUE}Retrieved {ORANGE}{len(result)}{BLUE} rows for RIC: {ORANGE}{rics}{BLUE} from {BLUE}{from_date} to {ORANGE}{to_date}{RESET}"
    )

    return result


def get_rics_h(rics, from_date=None, to_date=None, sleep=0, headers_legacy=True):
    """
    Retrieve 24-hour time series data for a given base RIC.

    Parameters
    ----------
    ric : str
        Base RIC (e.g., 'GMEIT') without hour suffix.
    from_date : str or datetime.date, optional
        Start date (default: 10 years ago).
    to_date : str or datetime.date, optional
        End date (default: today).
    sleep : int or float
        Seconds to sleep between API calls (default: 0).
    headers_legacy : bool
        Whether to return legacy column names (date, hour, ric, value, volume) or (DATE, HOUR, RIC, VALUE, VOLUME).

    Returns
    -------
    pd.DataFrame
        DataFrame with columns: DATE, HOUR, RIC, VALUE, VOLUME.
    """

    rics_id_24 = [f"{i:02d}" for i in range(1, 25)]
    rics_id_h = [f"{rics}{hour}" for hour in rics_id_24]

    if from_date is None:
        from_date = date.today() - timedelta(days=365 * 10)
    if to_date is None:
        to_date = date.today()

    data_fields = ["CF_NAME", "TRDPRC_1", "TR.ACCUMULATEDVOLUME"]
    frames = []

    for ric_h in rics_id_h:
        result = None
        try:
            result = ld.get_history(
                universe=ric_h,
                fields=data_fields,
                interval="1D",
                start=from_date,
                end=to_date,
            )
            time.sleep(sleep)
        except Exception as e:
            print(f"\033[31m[ERROR]\033[0m Failed to retrieve {ric_h}: {e}")
            continue

        if result is not None and not result.empty:
            result = result.reset_index()
        if "TR.ACCUMULATEDVOLUME" not in result.columns:
            result["TR.ACCUMULATEDVOLUME"] = None
            result["hour"] = ric_h
            frames.append(result)
        else:
            print(f"\033[33m[WARNING]\033[0m No data for {ric_h}")

    if not frames:
        return pd.DataFrame(columns=["date", "hour", "ric", "value", "volume"])

    df_h24 = pd.concat(frames, ignore_index=True)

    if df_h24["TRDPRC_1"].isna().all():
        df_h24 = pd.DataFrame(columns=["date", "hour", "ric", "value", "volume"])
    else:
        df_h24 = df_h24[df_h24["TRDPRC_1"].notna()]

    df_h24 = df_h24.rename(
        columns={
            "CF_NAME": "hour",
            "TRDPRC_1": "value",
            "TR.ACCUMULATEDVOLUME": "volume",
        }
    )

    df_h24["date"] = pd.to_datetime(df_h24["Date"])
    df_h24["hour"] = df_h24["hour"].str[-2:].astype(int)
    df_h24["ric"] = rics
    df_h24["value"] = pd.to_numeric(df_h24["value"], errors="coerce")
    df_h24["volume"] = pd.to_numeric(df_h24["volume"], errors="coerce")
    df_h24 = (
        df_h24[["date", "hour", "ric", "value", "volume"]]
        .sort_values(by=["date", "hour"])
        .reset_index(drop=True)
    )

    if df_h24["hour"].nunique() < 24:
        warnings.warn("Not all 24 hours are present in the data.")

    if headers_legacy is False:
        df_h24.columns = ["DATE", "HOUR", "RIC", "VALUE", "VOLUME"]

    # ANSI color codes
    GREEN = "\033[32m"
    ORANGE = "\033[33m"
    BLUE = "\033[34m"
    RESET = "\033[0m"

    print(
        f"{GREEN}[INFO]{RESET} "
        f"{BLUE}Retrieved {ORANGE}{len(df_h24)}{BLUE} rows for RIC: {ORANGE}{rics}{BLUE} from {BLUE}{from_date} to {ORANGE}{to_date}{RESET}"
    )

    return df_h24


def get_rics_f(rics, from_date=None, to_date=None, sleep=0, headers_legacy=True):
    """
    Retrieve Forward Market Data for a Given RIC.

    Parameters
    ----------
    rics : str
        RIC identifier (e.g., 'FDBMJ5').
    from_date : str or datetime.date, optional
        Start date (default: 10 years before today).
    to_date : str or datetime.date, optional
        End date (default: today).
    sleep : int or float
        Seconds to sleep between API calls (default: 0).
    headers_legacy : bool
        Whether to return legacy column names (date, ric, value, volume) or (DATE, RIC, VALUE, VOLUME).

    Returns
    -------
    pd.DataFrame
        DataFrame with columns: DATE, RIC, VALUE, VOLUME.
        If no data is found, returns an empty DataFrame.
    """
    from datetime import date, timedelta
    import time
    import pandas as pd

    if from_date is None:
        from_date = date.today() - timedelta(days=365 * 10)
    if to_date is None:
        to_date = date.today()

    data_fields = ["CF_NAME", "TRDPRC_1", "TR.ACCUMULATEDVOLUME"]
    result = None

    try:
        result = ld.get_history(
            universe=rics,
            fields=data_fields,
            interval="1D",
            start=from_date,
            end=to_date,
        )
        time.sleep(sleep)
    except Exception as e:
        print(f"\033[31m[ERROR]\033[0m Failed to retrieve {rics}: {e}")
        return pd.DataFrame(columns=["date", "ric", "value", "volume"])

    if result is not None and not result.empty:
        result = result.reset_index()
        n_cols = result.shape[1]

        if n_cols == 3:
            result.columns = ["date", "value", "volume"]
        elif n_cols == 2:
            result.columns = ["date", "value"]
            result["volume"] = pd.NA
        else:
            raise ValueError(f"Unexpected number of columns: {n_cols}")

        result["ric"] = rics
        result["value"] = pd.to_numeric(result["value"], errors="coerce")
        result["volume"] = pd.to_numeric(result["volume"], errors="coerce")
        result = (
            result[["date", "ric", "value", "volume"]]
            .sort_values("date")
            .reset_index(drop=True)
        )

        if result["value"].isna().all():
            result = pd.DataFrame(columns=["date", "ric", "value", "volume"])
        else:
            result = result[result["value"].notna()]
    else:
        result = pd.DataFrame(columns=["date", "ric", "value", "volume"])

    if headers_legacy is False:
        result.columns = ["DATE", "RIC", "VALUE", "VOLUME"]

    # ANSI color codes
    GREEN = "\033[32m"
    ORANGE = "\033[33m"
    BLUE = "\033[34m"
    RESET = "\033[0m"

    print(
        f"{GREEN}[INFO]{RESET} "
        f"{BLUE}Retrieved {ORANGE}{len(result)}{BLUE} rows for RIC: {ORANGE}{rics}{BLUE} from {BLUE}{from_date} to {ORANGE}{to_date}{RESET}"
    )

    return result
