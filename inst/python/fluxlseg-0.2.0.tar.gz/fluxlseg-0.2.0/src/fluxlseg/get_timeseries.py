
import pandas as pd
import lseg.data as ld
from lseg.data.content import historical_pricing
import warnings
from datetime import date, datetime, timedelta
import time

            result = ld.get_history(
                universe=ric_h,
                fields=data_fields,
                interval="daily",
                start=from_date,
                end=to_date
            )